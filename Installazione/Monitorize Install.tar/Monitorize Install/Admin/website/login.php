<?php
include("../inc/settings.php");

$user = $_POST["user"];
$pass = $_POST["pass"];
if($user == null || $pass == null){
	echo "0";
}else{
	$query = "select * from users where 
	session_start();
	
	$_SESSION["user"] = $user;
    echo "1";
}
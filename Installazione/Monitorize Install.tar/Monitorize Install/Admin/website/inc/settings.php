<?php
$db_server="host";
$db_user="dbuser";
$db_pass="dbpassword";
$db_name="apiKeys";
$referrer="http://www.stestaz.com/admin/";
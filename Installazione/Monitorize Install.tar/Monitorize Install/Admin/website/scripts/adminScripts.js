$(document).ready(function() {
	$("#newBtn").click(function(){
		window.location.href = "../admin/newKey.php";
	});
	$("#listBtn").click(function(){
		window.location.href = "../admin/listKeys.php";
	});
});
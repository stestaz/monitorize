<?php

$result=1;
setcookie("raspeinUser","",time()-3600,"/");
echo $result;
<?php
$dbUser="host";
$dbPass="password";
$dbServer="user";
$dbName="raspeinWeb";
$instId=1;
$apiKey="ntybo1rbvjc501ohwip809k1rtitmvnzeb1t3iuo";
$apiServer="http://www.stestaz.com/wss";
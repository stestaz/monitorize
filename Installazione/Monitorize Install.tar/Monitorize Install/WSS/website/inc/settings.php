<?php
/**
 * Created by PhpStorm.
 * User: stest
 * Date: 12/07/2016
 * Time: 21:59
 */

$db_api_server = 'host';
$db_api_username = 'dbuser';
$db_api_password= 'dbpassword!';
$db_api_db = 'apiKeys';

$db_model_server = 'host';
$db_model_username = 'dbuser';
$db_model_password = 'dbpassword!';
$db_model_db = 'raspeinModel';
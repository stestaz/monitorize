<?php
/**
 * Created by PhpStorm.
 * User: stest
 * Date: 16/07/2016
 * Time: 14:32
 *
 * Questa classe interfaccia API Manager e Authenticator, il suo scopo è verificare il livello richiesto per una determinata API e
 * confrontarlo con quello posseduto dal richiedente
 */

class tools {

    /*
     * Questa funzione prende in ingresso l'url inviato e da esso estrapola l'API richiesta
     */
    function explane_uri($string) {
        $string = str_replace("/wss/", '', $string);
        if ($string != "") {
            $vet = explode('/', $string);
            return $vet[0];
        } else
            return null;
    }

    /*passando una chiave di autorizzazione e una api richiesta verifico se vi è il livello di autorizzazione necessaria, ritorno:
        - 0 = richiesta non valida (es api non trovata)
        - 1 = livello non sufficiente
        - 2 = ok
    */
    function apiAuth($key,$reqApi){
        include ("/var/www/wss/inc/settings.php");
        $keyManagerConn = new mysqli($db_api_server,$db_api_username,$db_api_password,$db_api_db);
        $apiManagerConn = new mysqli($db_model_server,$db_model_username,$db_model_password,$db_model_db);
        $response =0;
        $keyLevel = 0;
        $getLevelQuery = "select a.level from apis a where a.enable=1 and a.key='".$key."'";
        if( $levelRes = $keyManagerConn->query($getLevelQuery)){
            if($levelRes->num_rows == 1){
                $rowLevel = $levelRes->fetch_assoc();
                $keyLevel = $rowLevel["level"];
            }
        }
        $keyManagerConn->close();
        if($keyLevel !=0){
            $getApiData = "select a.level,a.enable from availableApis a where a.name='".$reqApi."'";
            if($apiData = $apiManagerConn->query($getApiData)){
                if($apiData->num_rows ==1){
                    $rowData = $apiData->fetch_assoc();
                    if($rowData["enable"] == 1){
                        if($rowData["level"]<=$keyLevel){
                            $response = 2;
                        }
                        else{
                            $response = 1;
                        }
                    }
                }
            }
        }
        $apiManagerConn->close();
        return $response;
    }
}
-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Set 15, 2016 alle 14:08
-- Versione del server: 5.5.50-0+deb8u1
-- PHP Version: 5.6.24-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `raspeinModel`
--
CREATE DATABASE IF NOT EXISTS `raspeinModel` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `raspeinModel`;

-- --------------------------------------------------------

--
-- Struttura della tabella `availableApis`
--

CREATE TABLE IF NOT EXISTS `availableApis` (
`id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `level` int(11) NOT NULL,
  `enable` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `availableApis` (`id`, `name`, `level`, `enable`) VALUES
(1, 'testApi', 3, 1),
(2, 'getRaspi', 1, 1),
(3, 'getSensors', 1, 1),
(4, 'getData', 1, 1),
(5, 'addRaspi', 5, 1),
(6, 'getConfiguration', 1, 1),
(7, 'getRaspiFromName', 1, 1),
(8, 'addSensor', 5, 1),
(9, 'addData', 5, 1),
(10, 'getLastData', 1, 1),
(11, 'getTodayData', 1, 1),
(12, 'getFromToData', 1, 1),
(13, 'getRaspiFromInstId', 1, 1),
(14, 'editRaspi', 1, 1),
(15, 'setEnvironment', 3, 1);
-- --------------------------------------------------------

--
-- Struttura della tabella `configuration`
--

CREATE TABLE IF NOT EXISTS `configuration` (
`id` int(11) NOT NULL,
  `instId` int(11) NOT NULL,
  `apiKey` varchar(100) NOT NULL,
  `folder` varchar(500) NOT NULL,
  `twitterConsumerKey` varchar(100) NOT NULL,
  `twitterConsumerSecret` varchar(100) NOT NULL,
  `twitterAccessToken` varchar(100) NOT NULL,
  `twitterAccessTokenSecret` varchar(100) NOT NULL,
  `twitterContactName` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `raspberry`
--

CREATE TABLE IF NOT EXISTS `raspberry` (
`id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `tower` int(11) DEFAULT NULL,
  `position` int(100) DEFAULT NULL,
  `description` text,
  `enable` int(11) NOT NULL,
  `instId` int(11) NOT NULL,
  `color` varchar(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `sensorData`
--

CREATE TABLE IF NOT EXISTS `sensorData` (
`id` int(11) NOT NULL,
  `sensorId` int(11) NOT NULL,
  `value` float NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=50278 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `sensorOnRaspi`
--

CREATE TABLE IF NOT EXISTS `sensorOnRaspi` (
  `raspId` int(11) NOT NULL,
  `sensId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `sensors`
--

CREATE TABLE IF NOT EXISTS `sensors` (
`id` int(11) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `fromValue` double NOT NULL,
  `toValue` double NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struttura della tabella `sensorType`
--

CREATE TABLE IF NOT EXISTS `sensorType` (
`id` int(11) NOT NULL,
  `type` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `availableApis`
--
ALTER TABLE `availableApis`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `configuration`
--
ALTER TABLE `configuration`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `instId` (`instId`);

--
-- Indexes for table `raspberry`
--
ALTER TABLE `raspberry`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `sensorData`
--
ALTER TABLE `sensorData`
 ADD PRIMARY KEY (`id`), ADD KEY `sensorId` (`sensorId`);

--
-- Indexes for table `sensorOnRaspi`
--
ALTER TABLE `sensorOnRaspi`
 ADD KEY `raspId` (`raspId`), ADD KEY `sensId` (`sensId`);

--
-- Indexes for table `sensors`
--
ALTER TABLE `sensors`
 ADD PRIMARY KEY (`id`), ADD KEY `type` (`type`);

--
-- Indexes for table `sensorType`
--
ALTER TABLE `sensorType`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `availableApis`
--
ALTER TABLE `availableApis`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `configuration`
--
ALTER TABLE `configuration`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `raspberry`
--
ALTER TABLE `raspberry`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `sensorData`
--
ALTER TABLE `sensorData`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=50278;
--
-- AUTO_INCREMENT for table `sensors`
--
ALTER TABLE `sensors`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `sensorType`
--
ALTER TABLE `sensorType`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `sensorData`
--
ALTER TABLE `sensorData`
ADD CONSTRAINT `sensorData_ibfk_1` FOREIGN KEY (`sensorId`) REFERENCES `sensors` (`id`);

--
-- Limiti per la tabella `sensorOnRaspi`
--
ALTER TABLE `sensorOnRaspi`
ADD CONSTRAINT `sensorOnRaspi_ibfk_1` FOREIGN KEY (`raspId`) REFERENCES `raspberry` (`id`),
ADD CONSTRAINT `sensorOnRaspi_ibfk_2` FOREIGN KEY (`sensId`) REFERENCES `sensors` (`id`);

--
-- Limiti per la tabella `sensors`
--
ALTER TABLE `sensors`
ADD CONSTRAINT `sensors_ibfk_1` FOREIGN KEY (`type`) REFERENCES `sensorType` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

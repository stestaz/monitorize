<?php
/**
 * Created by PhpStorm.
 * User: stest
 * Date: 12/07/2016
 * Time: 21:30
 */

class wssManager {

}